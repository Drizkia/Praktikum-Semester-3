<?php
// LAKUKAN REQUIRE DULU

// LOGIKA KODE KAMU
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?= head("JUDUL TITLE");  ?>
</head>

<body>
  <?php navbar() ?>

  <main class="container my-5">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{kode kamu}" class="text-decoration-none" style="color: #4B774B;">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page">{kode kamu}</li>
      </ol>
    </nav>

    <h1 class="mb-4">Detail Data Roti</h1>

    <div class="card p-4 shadow-lg">
      <div class="d-flex flex-wrap gap-5 align-items-center">
        <img src="{kode kamu}" alt="{kode kamu}" class="rounded detail-image object-cover w-50 h-auto">

        <div>
          <h2 class="display-5 mb-3" style="color: #4B774B;">{kode kamu}</h2>

          <div class="mb-3">
            <p class="fs-5 m-0"><span class="fw-bold">{kode kamu}</p>
            <p class="fs-5 m-0"><span class="fw-bold">{kode kamu}</p>
            <p class="fs-5 m-0"><span class="fw-bold">{kode kamu}</span>
              <span class="fw-bold">
                {kode kamu}
              </span>
            </p>
          </div>

           <form action="{kode kamu}" method="post" class="mt-4">
              <button type="submit" name="beli" class="btn btn-primary btn-lg shadow">{kode kamu}</button>
            </form>

          <div class="mt-4 d-flex gap-2">
            <a href="{kode kamu}" class="btn btn-warning btn-sm">{kode kamu}</a>
            <a href="{kode kamu}" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">{kode kamu}</a>
          </div>
        </div>
      </div>
    </div>
  </main>
  <?php footer() ?>
</body>

</html>