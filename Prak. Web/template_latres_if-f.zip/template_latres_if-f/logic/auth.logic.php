<?php
session_start();
include "../config/koneksi.php";

// Kode Lainnya

// REGISTER
// Logika Register disini

// LOGIN
// Logika Login disini

// LOGOUT
// Logika Logout disini

mysqli_close($koneksi);
