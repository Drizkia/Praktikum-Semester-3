<?php
include "../config/koneksi.php";

// LOGIKA KAMU

mysqli_close($koneksi);
