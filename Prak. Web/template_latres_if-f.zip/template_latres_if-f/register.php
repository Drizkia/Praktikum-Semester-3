<?php
// LAKUKAN REQUIRE DULU

// LOGIKA KODE KAMU
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?= head("JUDUL TITLE");  ?>
</head>

<body class="d-flex justify-content-center align-items-center mt-5">
  <section class="w-50 shadow-lg mt-5 p-4 rounded">

    <h1 class="text-center">Register Admin</h1>

    <?php
    // ALERT STATUS TAMPIl
    listAlert($status);
    ?>


    <div class="card-body">
      <form action="{kode kamu}" method="post">
        <div class="mb-3">
          <label for="username" class="form-label">{kode kamu}</label>
          <input type="text" class="form-control" id="username" name="{kode kamu}" required>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">{kode kamu}</label>
          <input type="password" class="form-control" id="password" name="{kode kamu}" required>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">{kode kamu}</label>
          <input type="password" class="form-control" id="password" name="{kode kamu}" required>
        </div>
        <button type="submit" class="btn btn-primary w-100" name="register">Register</button>
      </form>
      <a href="{kode kamu}"><button type="submit" class="btn btn-outline-primary w-100 mt-3">Menuju ke Login</button></a>
    </div>

  </section>


  <?php footer() ?>
</body>

</html>