<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "latres_web-if-f";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
  die("Koneksi gagal: " . mysqli_connect_error());
}
