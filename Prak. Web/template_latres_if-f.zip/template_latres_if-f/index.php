<?php
// LAKUKAN REQUIRE DULU

// LOGIKA KODE KAMU
?>

<!DOCTYPE html>
<html lang="en">

<head>
<?= head("JUDUL TITLE");  ?>
</head>

<body>
  <?php navbar() ?>

  <main class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2>Selamat Datang, {kode kamu}</h2>
      <a href="{kode kamu}"><button type="button" class="btn btn-primary shadow-sm">{kode kamu}</button></a>
    </div>

    <section class="d-flex flex-wrap gap-4 mt-4 justify-content-start">
      {kode kamu}
    </section>
  </main>

  <?php footer() ?>
</body>

</html>