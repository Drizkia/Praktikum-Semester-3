<?php
// LAKUKAN REQUIRE DULU

// LOGIKA KODE KAMU
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?= head("JUDUL TITLE");  ?>
</head>

<body>
  <?php navbar() ?>

  <main class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2>Tambah Data Menu Roti Baru</h2>
    </div>

    <div class="card p-4 shadow-sm">
      <form action="{kode kamu}" method="post">
        <div class="mb-3">
          <label for="nama" class="form-label fw-bold">{kode kamu}</label>
          <input name="{kode kamu}" type="text" class="form-control" id="nama" placeholder="Contoh: Croissant" required>
        </div>
        <div class="mb-3">
          <label for="jenis" class="form-label fw-bold">{kode kamu}</label>
          <select name="{kode kamu}" id="jenis" class="form-select" aria-label="Default select example" required>
            <option selected disabled>Pilih jenis roti</option>
            {kode kamu}
          </select>
        </div>
        <div class="mb-3">
          <label for="harga" class="form-label fw-bold">{kode kamu}</label>
          <input name="{kode kamu}" type="number" class="form-control" id="harga" placeholder="Harga Roti, Contoh: 8000" min="0" required>
        </div>
        <div class="mb-4">
          <label for="gambar" class="form-label fw-bold">{kode kamu} (Link URL)</label>
          <input name="{kode kamu}" type="text" class="form-control" id="gambar" placeholder="{kode kamu} (Unsplash disarankan)" required>
        </div>
        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-primary w-75 shadow-sm">Simpan Data</button>
          <button type="reset" class="btn btn-outline-primary w-25">Reset Form</button>
        </div>
      </form>
    </div>
  </main>

  <?php footer() ?>
</body>

</html>